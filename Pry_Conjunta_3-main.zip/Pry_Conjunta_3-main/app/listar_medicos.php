<?php

//conexion a base de datos con conexion/db.php
require_once '../conexion/db.php';

// Consulta para obtener los médicos
$sql = "SELECT * FROM medicos";
$result = $conn->query($sql);
$medicos = $result->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de médicos</title>
    <link href="../public/lib/bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #e9ecef 0%, #f8f9fa 100%);
            min-height: 100vh;
        }
        .main-header {
            background: #0d6efd;
            color: #fff;
            padding: 2rem 0 1.5rem 0;
            border-radius: 0 0 2rem 2rem;
            box-shadow: 0 4px 16px rgba(13,110,253,0.08);
        }
        .card {
            border-radius: 1rem;
            box-shadow: 0 2px 12px rgba(0,0,0,0.07);
            border: none;
            transition: transform 0.2s;
        }
        .card:hover {
            transform: translateY(-4px) scale(1.02);
            box-shadow: 0 6px 24px rgba(13,110,253,0.12);
        }
        .card-title {
            color: #0d6efd;
            font-weight: 600;
        }
        .card-text {
            color: #495057;
        }
        .btn-custom {
            background: #0d6efd;
            color: #fff;
            border-radius: 2rem;
            font-weight: 500;
            margin: 0.25rem 0;
            transition: background 0.2s;
        }
        .btn-custom:hover {
            background: #084298;
            color: #fff;
        }
        .icon-circle {
            background: #e9ecef;
            border-radius: 50%;
            padding: 0.7rem;
            font-size: 2rem;
            color: #0d6efd;
            margin-bottom: 0.5rem;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/localization/messages_es.js"></script>
</head>
<body>
    <header class="main-header text-center mb-5 shadow-sm">
        <h1 class="display-5 fw-bold mb-2">
            <i class="bi bi-journal-text"></i> Lista de Médicos
        </h1>
        <p class="lead mb-0">Consulta y administra los médicos registrados</p>
    </header>
    <div class="container mt-4">
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered table-striped align-middle text-center" id="tabla_medicos">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Especialidad</th>
                            <th>Tarifa Por Hora</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($medicos as $medico): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($medico['id']); ?></td>
                                <td><?php echo htmlspecialchars($medico['nombre']); ?></td>
                                <td><?php echo htmlspecialchars($medico['especialidad']); ?></td>
                                <td><?php echo htmlspecialchars($medico['tarifa_por_hora']); ?></td>
                                <td>
                                    <button data-id="<?php echo $medico['id']; ?>" class="btn btn-warning btn-sm btn-editar-medico">
                                        <i class="bi bi-pencil-square"></i> Editar
                                    </button>
                                    <button data-id="<?php echo $medico['id']; ?>" class="btn btn-danger btn-sm btn-eliminar-medico">
                                        <i class="bi bi-trash"></i> Eliminar
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <a
                    href="../index.html"
                    class="btn btn-outline-primary w-100 mt-2 shadow-sm d-flex align-items-center justify-content-center"
                    style="font-weight: 500;"
                >
                    <i class="bi bi-arrow-left-circle me-2"></i> Regresar
                </a>
            </div>
        </div>
    </div>
    <footer class="text-center mt-5 mb-3 text-muted small">
        &copy; <?php echo date('Y'); ?> Gestión de Citas Médicas
    </footer>
    <!-- Modal -->
    <div class="modal fade" id="modalEditarMedico" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-3">
            <div class="modal-header bg-primary text-white rounded-top">
                <h5 class="modal-title fw-bold" id="exampleModalLabel">
                    <i class="bi bi-pencil-square me-2"></i> Editar Médico
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body bg-light">
                <input type="hidden" id="modal-id-medico">
                <div class="mb-3">
                    <label for="modal-nombre" class="form-label">Nombre</label>
                    <input type="text" class="form-control" id="modal-nombre" required>
                </div>
                <div class="mb-3">
                    <label for="modal-especialidad" class="form-label">Especialidad</label>
                    <input type="text" class="form-control" id="modal-especialidad" required>
                </div>
                <div class="mb-3">
                    <label for="modal-tarifa" class="form-label">Tarifa Por Hora</label>
                    <input type="number" class="form-control" id="modal-tarifa" required>
                </div>
            </div>
            <div class="modal-footer bg-white rounded-bottom">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle me-1"></i> Cancelar
                </button>
                <button type="button" id="btn-actualizar-medico" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i> Actualizar
                </button>
            </div>
        </div>
    </div>
    </div>
    
    <script src="../public/lib/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        const modalEditarMedico = new bootstrap.Modal(
            document.getElementById('modalEditarMedico'), {
            keyboard: false
        });

        // Validación visual de campos vacíos en el modal
        function validarModalMedico() {
            $("#modalEditarMedico form").validate({
                highlight: function(element) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element) {
                    $(element).removeClass('is-invalid');
                },
                rules: {
                    'modal-nombre': "required",
                    'modal-especialidad': {
                        required: true,
                        maxlength: 30
                    },
                    'modal-tarifa': {
                        required: true,
                        number: true,
                        min: 1
                    }
                },
                messages: {
                    'modal-nombre': "Ingrese el nombre del médico",
                    'modal-especialidad': {
                        required: "Ingrese la especialidad",
                        maxlength: "Máximo 30 caracteres"
                    },
                    'modal-tarifa': {
                        required: "Ingrese la tarifa por hora",
                        number: "Solo números",
                        min: "Debe ser mayor a 0"
                    }
                }
            });
        }

        // Crear el formulario dinámico para el modal si no existe
        if (!$("#modalEditarMedico form").length) {
            $('<form></form>').appendTo('#modalEditarMedico .modal-body');
            $('#modalEditarMedico .modal-body > div').appendTo('#modalEditarMedico form');
        }

        validarModalMedico();

        var tablaMedicos = document.getElementById('tabla_medicos');
        tablaMedicos.addEventListener('click', function(event){
            // Editar
            if(event.target.closest('.btn-editar-medico')){
                var btn = event.target.closest('.btn-editar-medico');
                var id = btn.dataset.id;
                fetch('buscarMedicoPorId.php', {
                    method:'POST',
                    headers:{
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ id: id })
                }).then(function(response) {
                    return response.json();
                }).then(function(request){
                    modalEditarMedico.show();
                    if (typeof request === 'object' && request !== null) {
                        document.getElementById('modal-id-medico').value = request.id ?? '';
                        document.getElementById('modal-nombre').value = request.nombre ?? '';
                        document.getElementById('modal-especialidad').value = request.especialidad ?? '';
                        document.getElementById('modal-tarifa').value = request.tarifa_por_hora ?? '';
                    } else {
                        document.getElementById('modal-id-medico').value = '';
                        document.getElementById('modal-nombre').value = '';
                        document.getElementById('modal-especialidad').value = '';
                        document.getElementById('modal-tarifa').value = '';
                    }
                });
            }
            // Eliminar
            if(event.target.closest('.btn-eliminar-medico')){
                var btn = event.target.closest('.btn-eliminar-medico');
                var id = btn.dataset.id;
                var nombreMedico = btn.closest('tr').querySelector('td:nth-child(2)').textContent;
                Swal.fire({
                    title: `¿Seguro que deseas eliminar el médico "${nombreMedico}"?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Sí, eliminar',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if(result.isConfirmed){
                        fetch('eliminar_medico.php', {
                            method:'POST',
                            headers:{
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({ id: id })
                        }).then(function(response) {
                            return response.json();
                        }).then(function(request){
                            Swal.fire({
                                icon: request.error ? 'error' : 'success',
                                title: request.error ? 'Error' : 'Eliminado',
                                text: request.error || `Médico "${nombreMedico}" eliminado correctamente`,
                                timer: 2000,
                                showConfirmButton: false
                            });
                            setTimeout(() => location.reload(), 1200);
                        });
                    }
                });
            }
        });

        // Actualizar médico
        var btnActualizarMedico = document.getElementById('btn-actualizar-medico');
        btnActualizarMedico.addEventListener('click', function(){
            // Validar antes de enviar
            if (!$("#modalEditarMedico form").valid()) {
                return;
            }
            let id = document.getElementById('modal-id-medico').value;
            let nombre = document.getElementById('modal-nombre').value;
            let especialidad = document.getElementById('modal-especialidad').value;
            let tarifa_por_hora = document.getElementById('modal-tarifa').value;

            Swal.fire({
                title: '¿Estas seguro de modificar este médico?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Sí, modificar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if(result.isConfirmed){
                    fetch('actualizarMedico.php', {
                        method:'POST',
                        headers:{
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ 
                            id: id,
                            nombre: nombre,
                            especialidad: especialidad,
                            tarifa_por_hora: tarifa_por_hora
                        })
                    }).then(function(response) {
                        return response.json();
                    }).then(function(request){
                        modalEditarMedico.hide();
                        Swal.fire({
                            icon: request.error ? 'error' : 'success',
                            title: request.error ? 'Error' : 'Actualizado',
                            text: request.error || `Médico "${nombre}" actualizado correctamente`,
                            timer: 2000,
                            showConfirmButton: false
                        });
                        setTimeout(() => location.reload(), 1200);
                    });
                }
            });
        });
    </script>
</body>
</html>