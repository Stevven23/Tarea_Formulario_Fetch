<?php
require_once '../conexion/db.php';

// Recibir datos por JSON
$request = json_decode(file_get_contents("php://input"), true);

if (!isset($request['id'])) {
    echo json_encode(["error" => "ID no proporcionado"]);
    exit;
}

$id = $request['id'];

$consulta = "DELETE FROM pacientes WHERE id = :id";
$stmt = $conn->prepare($consulta);
$stmt->bindParam(':id', $id);

if ($stmt->execute()) {
    echo json_encode(["message" => "Paciente eliminado correctamente"]);
} else {
    echo json_encode(["error" => "No se pudo eliminar el paciente"]);
}
?>