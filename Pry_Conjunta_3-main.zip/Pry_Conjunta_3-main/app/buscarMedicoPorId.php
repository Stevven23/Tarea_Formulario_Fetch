<?php
require_once '../conexion/db.php';
$request = json_decode(file_get_contents("php://input"), true);

$id = $request['id'] ?? null;
if (!$id) {
    echo json_encode(['error' => 'ID de médico no proporcionado']);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM medicos WHERE id = :id");
$stmt->bindParam(':id', $id);
$stmt->execute();
$medico = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode($medico);
?>