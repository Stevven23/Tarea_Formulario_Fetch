<?php 

// conexion a base de datos con conexion/db.php
require_once '../conexion/db.php';

// Consulta para obtener las citas con nombres de pacientes, medicos, hora de inicio y fin, duración y costo total

$sql = "SELECT 
            c.id,
            p.nombre AS nombre_paciente, 
            m.nombre AS nombre_medico,
            m.especialidad,
            c.fecha,
            c.hora_inicio,
            c.hora_fin,
            c.duracion,
            c.costo_total,
            c.estado
        FROM citas c
        INNER JOIN pacientes p ON c.paciente_id = p.id
        INNER JOIN medicos m ON c.medico_id = m.id";

$stmt = $conn->prepare($sql);
$stmt->execute();
$citas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener pacientes y medicos para los selects del modal
$pacientes = $conn->query("SELECT id, nombre FROM pacientes")->fetchAll(PDO::FETCH_ASSOC);
$medicos = $conn->query("SELECT id, nombre FROM medicos")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Notas</title>
    <link href="../public/lib/bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #e9ecef 0%, #f8f9fa 100%);
            min-height: 100vh;
        }
        .main-header {
            background: #0d6efd;
            color: #fff;
            padding: 2rem 0 1.5rem 0;
            border-radius: 0 0 2rem 2rem;
            box-shadow: 0 4px 16px rgba(13,110,253,0.08);
        }
        .card {
            border-radius: 1rem;
            box-shadow: 0 2px 12px rgba(0,0,0,0.07);
            border: none;
            transition: transform 0.2s;
        }
        .card:hover {
            transform: translateY(-4px) scale(1.02);
            box-shadow: 0 6px 24px rgba(13,110,253,0.12);
        }
        .table-formal {
            background: #fff;
            border-radius: 1rem;
            box-shadow: 0 2px 12px rgba(0,0,0,0.07);
            overflow: hidden;
        }
        .table-formal th {
            background: #0d6efd;
            color: #fff;
            font-weight: 600;
            border: none;
        }
        .table-formal td {
            border: none;
        }
    </style>
</head>
<body class="bg-light">
    <header class="main-header text-center mb-5 shadow-sm">
        <h1 class="display-5 fw-bold mb-2">
            <i class="bi bi-list-ol"></i> Lista de Citas Agendadas
        </h1>
        <p class="lead mb-0">Consulta y administra las citas registradas</p>
    </header>
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
        <div class="card shadow-lg w-100" style="max-width: 1100px;">
            <div class="card-body">
                <table class="table table-striped table-formal align-middle text-center" id="tabla_citas">
                    <thead>
                        <tr>
                            <th>Paciente</th>
                            <th>Médico</th>
                            <th>Fecha</th>
                            <th>Hora Inicio</th>
                            <th>Hora Fin</th>
                            <th>Duración</th>
                            <th>Costo Total</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($citas as $cita): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($cita['nombre_paciente']); ?></td>
                                <td><?php echo htmlspecialchars($cita['nombre_medico']); ?></td>
                                <td><?php echo htmlspecialchars($cita['fecha']); ?></td>
                                <td><?php echo htmlspecialchars($cita['hora_inicio']); ?></td>
                                <td><?php echo htmlspecialchars($cita['hora_fin']); ?></td>
                                <td><?php echo htmlspecialchars($cita['duracion']); ?></td>
                                <td><?php echo htmlspecialchars($cita['costo_total']); ?></td>
                                <td>
                                    <?php if ($cita['estado'] == 'programada'): ?>
                                        <span class="badge bg-success">Programada</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Cancelada</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button 
                                        data-id="<?php echo $cita['id']; ?>"
                                        class="btn btn-warning btn-sm btn-editar-cita">
                                        <i class="bi bi-pencil-square"></i> Editar
                                    </button>
                                    <button data-id="<?php echo $cita['id']; ?>" class="btn btn-danger btn-sm btn-eliminar-cita">
                                        <i class="bi bi-trash"></i> Eliminar
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <a
                    href="../index.html"
                    class="btn btn-outline-primary w-100 mt-2 shadow-sm d-flex align-items-center justify-content-center"
                    style="font-weight: 500;"
                >
                    <i class="bi bi-arrow-left-circle me-2"></i> Regresar
                </a>
            </div>
        </div>
    </div>
    <!-- Modal Editar Cita -->
    <div class="modal fade" id="modalEditarCita" tabindex="-1" aria-labelledby="modalEditarCitaLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg rounded-3">
            <div class="modal-header bg-primary text-white rounded-top">
                <h5 class="modal-title fw-bold" id="modalEditarCitaLabel">
                    <i class="bi bi-pencil-square me-2"></i> Editar Cita
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body bg-light">
                <input type="hidden" id="modal-id-cita">
                <div class="mb-3">
                    <label for="modal-paciente" class="form-label">Paciente</label>
                    <select id="modal-paciente" class="form-select" required>
                        <option value="">--Seleccione paciente--</option>
                        <?php foreach ($pacientes as $paciente): ?>
                            <option value="<?php echo $paciente['id']; ?>"><?php echo htmlspecialchars($paciente['nombre']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="modal-medico" class="form-label">Médico</label>
                    <select id="modal-medico" class="form-select" required>
                        <option value="">--Seleccione médico--</option>
                        <?php foreach ($medicos as $medico): ?>
                            <option value="<?php echo $medico['id']; ?>"><?php echo htmlspecialchars($medico['nombre']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="modal-fecha" class="form-label">Fecha</label>
                    <input type="date" name="modal-fecha" id="modal-fecha" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="modal-hora_inicio" class="form-label">Hora Inicio</label>
                    <input type="time" name="modal-hora_inicio" id="modal-hora_inicio" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="modal-hora_fin" class="form-label">Hora Fin</label>
                    <input type="time" name="modal-hora_fin" id="modal-hora_fin" class="form-control" required>
                </div>
            </div>
            <div class="modal-footer bg-white rounded-bottom">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle me-1"></i> Cancelar
                </button>
                <button type="button" id="btn-actualizar-cita" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i> Actualizar
                </button>
            </div>
            </div>
        </div>
    </div>
    <script src="../public/lib/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/localization/messages_es.js"></script>
    <script>
        const modalEditarCita = new bootstrap.Modal(document.getElementById('modalEditarCita'), { keyboard: false });

        // Establecer el mínimo de fecha al día actual en el modal
        var hoy = new Date().toISOString().split('T')[0];
        document.getElementById('modal-fecha').setAttribute('min', hoy);

        // Validación visual de campos vacíos en el modal
        function validarModalCita() {
            $("#modalEditarCita form").validate({
                highlight: function(element) { $(element).addClass('is-invalid'); },
                unhighlight: function(element) { $(element).removeClass('is-invalid'); },
                rules: {
                    'modal-paciente': "required",
                    'modal-medico': "required",
                    'modal-fecha': {
                        required: true,
                        min: hoy
                    },
                    'modal-hora_inicio': "required",
                    'modal-hora_fin': "required"
                },
                messages: {
                    'modal-paciente': "Seleccione paciente",
                    'modal-medico': "Seleccione médico",
                    'modal-fecha': {
                        required: "Ingrese la fecha",
                        min: "La fecha debe ser igual o posterior a hoy"
                    },
                    'modal-hora_inicio': "Ingrese hora de inicio",
                    'modal-hora_fin': "Ingrese hora de fin"
                }
            });
        }
        // Crear el formulario dinámico para el modal si no existe
        if (!$("#modalEditarCita form").length) {
            $('<form></form>').appendTo('#modalEditarCita .modal-body');
            $('#modalEditarCita .modal-body > div').appendTo('#modalEditarCita form');
        }
        validarModalCita();

        document.getElementById('tabla_citas').addEventListener('click', function(event){
            // Editar
            if(event.target.closest('.btn-editar-cita')){
                var btn = event.target.closest('.btn-editar-cita');
                var id = btn.dataset.id;
                fetch('buscarCitaPorId.php', {
                    method:'POST',
                    headers:{
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ id: id })
                }).then(function(response) {
                    return response.json();
                }).then(function(cita){
                    modalEditarCita.show();
                    if (typeof cita === 'object' && cita !== null) {
                        document.getElementById('modal-id-cita').value = cita.id ?? '';
                        document.getElementById('modal-paciente').value = cita.paciente_id ?? '';
                        document.getElementById('modal-medico').value = cita.medico_id ?? '';
                        document.getElementById('modal-fecha').value = cita.fecha ?? '';
                        document.getElementById('modal-hora_inicio').value = cita.hora_inicio ?? '';
                        document.getElementById('modal-hora_fin').value = cita.hora_fin ?? '';
                    } else {
                        document.getElementById('modal-id-cita').value = '';
                        document.getElementById('modal-paciente').value = '';
                        document.getElementById('modal-medico').value = '';
                        document.getElementById('modal-fecha').value = '';
                        document.getElementById('modal-hora_inicio').value = '';
                        document.getElementById('modal-hora_fin').value = '';
                    }
                });
            }
            // Eliminar
            if(event.target.closest('.btn-eliminar-cita')){
                var btn = event.target.closest('.btn-eliminar-cita');
                var id = btn.dataset.id;
                Swal.fire({
                    title: `¿Seguro que deseas eliminar esta cita?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Sí, eliminar',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if(result.isConfirmed){
                        fetch('eliminar_citas.php', {
                            method:'POST',
                            headers:{
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({ id: id })
                        }).then(function(response) {
                            return response.json();
                        }).then(function(request){
                            Swal.fire({
                                icon: request.error ? 'error' : 'success',
                                title: request.error ? 'Error' : 'Eliminado',
                                text: request.error || `Cita eliminada correctamente`,
                                timer: 2000,
                                showConfirmButton: false
                            });
                            setTimeout(() => location.reload(), 1200);
                        });
                    }
                });
            }
        });

        // Actualizar cita
        document.getElementById('btn-actualizar-cita').addEventListener('click', function(){
            // Validar antes de enviar
            if (!$("#modalEditarCita form").valid()) {
                return;
            }
            let id = document.getElementById('modal-id-cita').value;
            let paciente_id = document.getElementById('modal-paciente').value;
            let medico_id = document.getElementById('modal-medico').value;
            let fecha = document.getElementById('modal-fecha').value;
            let hora_inicio = document.getElementById('modal-hora_inicio').value;
            let hora_fin = document.getElementById('modal-hora_fin').value;

            Swal.fire({
                title: '¿Estas seguro de modificar la cita?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Sí, modificar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if(result.isConfirmed){
                    fetch('actualizarCita.php', {
                        method:'POST',
                        headers:{
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ 
                            id: id,
                            paciente_id: paciente_id,
                            medico_id: medico_id,
                            fecha: fecha,
                            hora_inicio: hora_inicio,
                            hora_fin: hora_fin
                        })
                    }).then(function(response) {
                        return response.json();
                    }).then(function(request){
                        modalEditarCita.hide();
                        Swal.fire({
                            icon: request.error ? 'error' : 'success',
                            title: request.error ? 'Error' : 'Actualizado',
                            text: request.error || `Cita actualizada correctamente`,
                            timer: 2000,
                            showConfirmButton: false
                        });
                        setTimeout(() => location.reload(), 1200);
                    });
                }
            });
        });
    </script>
</body>
</html>