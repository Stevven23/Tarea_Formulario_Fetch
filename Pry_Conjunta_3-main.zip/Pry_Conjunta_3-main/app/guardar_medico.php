<?php

// Cinectar a base de datos con conexion/db.php
require_once '../conexion/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'] ?? '';
    $especialidad = $_POST['especialidad'] ?? '';
    $tarifa_por_hora = $_POST['tarifa_por_hora'] ?? '';

    try {
        // Ingresar datos a la base de datos
        $sql = "INSERT INTO medicos (nombre, especialidad, tarifa_por_hora) VALUES (:nombre, :especialidad, :tarifa_por_hora)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':especialidad', $especialidad);
        $stmt->bindParam(':tarifa_por_hora', $tarifa_por_hora);
        $stmt->execute();

        $response = [
            'success' => true,
            'message' => 'Materia creada exitosamente'
        ];
    } catch (PDOException $e) {
        $response = [
            'success' => false,
            'error' => 'Error al guardar la materia: ' . $e->getMessage()
        ];
    }
} else {
    $response = [
        'success' => false,
        'error' => 'Método no permitido'
    ];
}

header('Content-Type: application/json');
echo json_encode($response);
exit;
?>