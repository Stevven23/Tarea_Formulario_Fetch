<?php
require_once '../conexion/db.php';
$pacientes = $conn->query("SELECT id, nombre FROM pacientes")->fetchAll(PDO::FETCH_ASSOC);
$medicos = $conn->query("SELECT id, nombre FROM medicos")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agendar Cita</title>
    <link href="../public/lib/bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/toastify-js/src/toastify.min.css">
    <style>
        body { background: linear-gradient(135deg, #e9ecef 0%, #f8f9fa 100%); min-height: 100vh; }
        .main-header { background: #0d6efd; color: #fff; padding: 2rem 0 1.5rem 0; border-radius: 0 0 2rem 2rem; box-shadow: 0 4px 16px rgba(13,110,253,0.08);}
        .card { border-radius: 1rem; box-shadow: 0 2px 12px rgba(0,0,0,0.07); border: none; transition: transform 0.2s;}
        .card:hover { transform: translateY(-4px) scale(1.02); box-shadow: 0 6px 24px rgba(13,110,253,0.12);}
        .card-title { color: #0d6efd; font-weight: 600;}
        .btn-custom { background: #0d6efd; color: #fff; border-radius: 2rem; font-weight: 500; margin: 0.25rem 0; transition: background 0.2s;}
        .btn-custom:hover { background: #084298; color: #fff;}
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/localization/messages_es.js"></script>
</head>
<body>
    <header class="main-header text-center mb-5 shadow-sm">
        <h1 class="display-5 fw-bold mb-2"><i class="bi bi-calendar-plus"></i> Agendar Cita</h1>
    </header>
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 70vh;">
        <div class="card shadow-lg w-100" style="max-width: 600px;">
            <div class="card-body">
                <form id="formCita">
                    <div class="mb-3">
                        <label for="paciente_id" class="form-label">Paciente</label>
                        <select id="paciente_id" name="paciente_id" class="form-select" required>
                            <option value="">--Seleccione paciente--</option>
                            <?php foreach ($pacientes as $p): ?>
                                <option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['nombre']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="medico_id" class="form-label">Médico</label>
                        <select id="medico_id" name="medico_id" class="form-select" required>
                            <option value="">--Seleccione médico--</option>
                            <?php foreach ($medicos as $m): ?>
                                <option value="<?php echo $m['id']; ?>"><?php echo htmlspecialchars($m['nombre']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="fecha" class="form-label">Fecha</label>
                        <input type="date" class="form-control" id="fecha" name="fecha" required>
                    </div>
                    <div class="mb-3">
                        <label for="hora_inicio" class="form-label">Hora Inicio</label>
                        <input type="time" class="form-control" id="hora_inicio" name="hora_inicio" required>
                    </div>
                    <div class="mb-3">
                        <label for="hora_fin" class="form-label">Hora Fin</label>
                        <input type="time" class="form-control" id="hora_fin" name="hora_fin" required>
                    </div>
                    <button type="submit" class="btn btn-custom w-100">Agendar Cita</button>
                </form>
                <a
                    href="../index.html"
                    class="btn btn-outline-primary w-100 mt-3 shadow-sm d-flex align-items-center justify-content-center"
                    style="font-weight: 500;"
                >
                    <i class="bi bi-arrow-left-circle me-2"></i> Regresar
                </a>
            </div>
        </div>
    </div>
    <script src="https://unpkg.com/toastify-js"></script>
    <script>
        $(function(){
            // Establecer el mínimo de fecha al día actual
            var hoy = new Date().toISOString().split('T')[0];
            $('#fecha').attr('min', hoy);

            $("#formCita").validate({
                highlight: function(element) { $(element).addClass('is-invalid'); },
                unhighlight: function(element) { $(element).removeClass('is-invalid'); },
                rules: {
                    paciente_id: "required",
                    medico_id: "required",
                    fecha: {
                        required: true,
                        min: hoy
                    },
                    hora_inicio: "required",
                    hora_fin: "required"
                },
                messages: {
                    paciente_id: "Seleccione paciente",
                    medico_id: "Seleccione médico",
                    fecha: {
                        required: "Ingrese la fecha",
                        min: "La fecha debe ser igual o posterior a hoy"
                    },
                    hora_inicio: "Ingrese hora de inicio",
                    hora_fin: "Ingrese hora de fin"
                },
                submitHandler: function(form) {
                    const formData = new FormData(form);
                    fetch('guardar_citas.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(r => r.json())
                    .then(data => {
                        if(data.success){
                            Toastify({
                                text: "Cita agendada correctamente",
                                duration: 3000,
                                gravity: "top",
                                position: "right",
                                style: { background: "linear-gradient(to right, #00b09b, #96c93d)" }
                            }).showToast();
                            form.reset();
                            $(".form-control, .form-select").removeClass("is-invalid");
                        }else{
                            Toastify({
                                text: data.error || "Error al agendar cita",
                                duration: 3000,
                                gravity: "top",
                                position: "right",
                                style: { background: "linear-gradient(to right, #ff5f6d, #ffc371)" }
                            }).showToast();
                        }
                    })
                    .catch(() => {
                        Toastify({
                            text: "Error al conectar con el servidor",
                            duration: 3000,
                            gravity: "top",
                            position: "right",
                            style: { background: "linear-gradient(to right, #ff5f6d, #ffc371)" }
                        }).showToast();
                    });
                }
            });
        });
    </script>
</body>
</html>