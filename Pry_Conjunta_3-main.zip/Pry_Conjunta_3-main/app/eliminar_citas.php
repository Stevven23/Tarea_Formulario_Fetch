<?php
require_once '../conexion/db.php';

// Recibir datos por JSON
$request = json_decode(file_get_contents("php://input"), true);

$id = $request['id'] ?? null;
if (!$id) {
    echo json_encode(['error' => 'ID de cita no proporcionado']);
    exit;
}

$stmt = $conn->prepare("DELETE FROM citas WHERE id = :id");
$stmt->bindParam(':id', $id);

if ($stmt->execute()) {
    echo json_encode(['message' => 'Cita eliminada correctamente']);
} else {
    echo json_encode(['error' => 'No se pudo eliminar la cita']);
}
?>