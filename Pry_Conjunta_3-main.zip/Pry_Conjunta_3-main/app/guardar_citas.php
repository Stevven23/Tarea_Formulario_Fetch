<?php
require_once '../conexion/db.php';

$paciente_id = $_POST['paciente_id'] ?? '';
$medico_id = $_POST['medico_id'] ?? '';
$fecha = $_POST['fecha'] ?? '';
$hora_inicio = $_POST['hora_inicio'] ?? '';
$hora_fin = $_POST['hora_fin'] ?? '';

if (!$paciente_id || !$medico_id || !$fecha || !$hora_inicio || !$hora_fin) {
    echo json_encode(['success' => false, 'error' => 'Todos los campos son obligatorios']);
    exit;
}

// Calcular duración en minutos
function calcularDuracion($inicio, $fin) {
    $t1 = strtotime($inicio);
    $t2 = strtotime($fin);
    if ($t2 > $t1) {
        return round(($t2 - $t1) / 60);
    }
    return 0;
}
$duracion = calcularDuracion($hora_inicio, $hora_fin);

// Obtener tarifa por hora del médico
$stmtTarifa = $conn->prepare("SELECT tarifa_por_hora FROM medicos WHERE id = :id");
$stmtTarifa->bindParam(':id', $medico_id);
$stmtTarifa->execute();
$tarifa = $stmtTarifa->fetchColumn();
if ($tarifa === false) $tarifa = 0;

// Calcular costo total (proporcional a la duración)
$costo_total = round(($duracion / 60) * $tarifa, 2);

try {
    $sql = "INSERT INTO citas (paciente_id, medico_id, fecha, hora_inicio, hora_fin, duracion, costo_total, estado) 
            VALUES (:paciente_id, :medico_id, :fecha, :hora_inicio, :hora_fin, :duracion, :costo_total, 'programada')";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':paciente_id', $paciente_id);
    $stmt->bindParam(':medico_id', $medico_id);
    $stmt->bindParam(':fecha', $fecha);
    $stmt->bindParam(':hora_inicio', $hora_inicio);
    $stmt->bindParam(':hora_fin', $hora_fin);
    $stmt->bindParam(':duracion', $duracion);
    $stmt->bindParam(':costo_total', $costo_total);
    $stmt->execute();

    echo json_encode(['success' => true, 'message' => 'Cita agendada correctamente']);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error al guardar la cita: ' . $e->getMessage()]);
}
exit;
?>