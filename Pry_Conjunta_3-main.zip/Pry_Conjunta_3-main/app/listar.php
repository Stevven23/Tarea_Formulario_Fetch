<?php

//conexion a base de datos con conexion/db.php
require_once '../conexion/db.php';

// Consulta para obtener los pacientes
$sql = "SELECT * FROM pacientes";
$result = $conn->query($sql);
$result->execute();
$pacientes = $result->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Pacientes</title>
    <!-- Bootstrap CSS -->
    <link href="../public/lib/bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/localization/messages_es.js"></script>
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/toastify-js/src/toastify.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #e9ecef 0%, #f8f9fa 100%) !important;
            min-height: 100vh;
        }
        .main-header {
            background: #0d6efd !important;
            color: #fff;
            padding: 2rem 0 1.5rem 0;
            border-radius: 0 0 2rem 2rem;
            box-shadow: 0 4px 16px rgba(13,110,253,0.08);
        }
        .card {
            border-radius: 1rem;
            box-shadow: 0 2px 12px rgba(0,0,0,0.07);
            border: none;
            transition: transform 0.2s;
            background-color: #fff !important;
        }
        .card:hover {
            transform: translateY(-4px) scale(1.02);
            box-shadow: 0 6px 24px rgba(13,110,253,0.12);
        }
        .card-title {
            color: #0d6efd !important;
            font-weight: 600;
        }
        .card-text {
            color: #495057 !important;
        }
        .btn-custom {
            background: #0d6efd !important;
            color: #fff !important;
            border-radius: 2rem;
            font-weight: 500;
            margin: 0.25rem 0;
            transition: background 0.2s;
        }
        .btn-custom:hover {
            background: #084298 !important;
            color: #fff !important;
        }
        .icon-circle {
            background: #e9ecef !important;
            border-radius: 50%;
            padding: 0.7rem;
            font-size: 2rem;
            color: #0d6efd !important;
            margin-bottom: 0.5rem;
        }
    </style>
</head>
<body>
    <header class="main-header text-center mb-5 shadow-sm">
        <h1 class="display-5 fw-bold mb-2">
            <i class="bi bi-people"></i> Lista de Pacientes
        </h1>
        <p class="lead mb-0">Consulta y administra los pacientes registrados</p>
    </header>
    <div class="container mt-4">
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered table-striped align-middle text-center" id="tabla_paciente">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Correo</th>
                            <th>Teléfono</th>
                            <th>Fecha Nacimiento</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pacientes as $paciente): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($paciente['id']); ?></td>
                                <td><?php echo htmlspecialchars($paciente['nombre']); ?></td>
                                <td><?php echo htmlspecialchars($paciente['correo']); ?></td>
                                <td><?php echo htmlspecialchars($paciente['telefono']); ?></td>
                                <td><?php echo htmlspecialchars($paciente['fecha_nacimiento']); ?></td>
                                <td>
                                    <button data-id="<?php echo $paciente['id']; ?>" class="btn btn-warning btn-sm btn-editar-paciente">
                                        <i class="bi bi-pencil-square"></i> Editar
                                    </button>
                                    <button data-id="<?php echo $paciente['id']; ?>" class="btn btn-danger btn-sm btn-eliminar-paciente">
                                        <i class="bi bi-trash"></i> Eliminar
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <a
                    href="../index.html"
                    class="btn btn-outline-primary w-100 mt-2 shadow-sm d-flex align-items-center justify-content-center"
                    style="font-weight: 500;"
                >
                    <i class="bi bi-arrow-left-circle me-2"></i> Regresar
                </a>
            </div>
        </div>
    </div>
    <footer class="text-center mt-5 mb-3 text-muted small">
        &copy; <?php echo date('Y'); ?> Gestión de Citas Médicas
    </footer>
    <!-- Modal -->
    <div class="modal fade" id="modalEditarPaciente" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-3">
        <div class="modal-header bg-primary text-white rounded-top">
            <h5 class="modal-title fw-bold" id="exampleModalLabel">
                <i class="bi bi-pencil-square me-2"></i> Editar Paciente
            </h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body bg-light">
            <input type="hidden" id="modal-id">
            <div class="mb-3">
                <label for="modal-nombre" class="form-label">Nombre</label>
                <input type="text" class="form-control" id="modal-nombre" required>
            </div>
            <div class="mb-3">
                <label for="modal-correo" class="form-label">Correo</label>
                <input type="email" class="form-control" id="modal-correo" required>
            </div>
            <div class="mb-3">
                <label for="modal-telefono" class="form-label">Teléfono</label>
                <input type="number" class="form-control" id="modal-telefono" required maxlength="10" pattern="\d{10}">
                <div class="form-text">Debe contener exactamente 10 números.</div>
            </div>
            <div class="mb-3">
                <label for="modal-fecha_nacimiento" class="form-label">Fecha Nacimiento</label>
                <input type="date" class="form-control" id="modal-fecha_nacimiento" required>
            </div>
        </div>
        <div class="modal-footer bg-white rounded-bottom">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                <i class="bi bi-x-circle me-1"></i> Cancelar
            </button>
            <button type="button" id="btn-actualizar-paciente" class="btn btn-primary">
                <i class="bi bi-save me-1"></i> Actualizar
            </button>
        </div>
        </div>
    </div>
    </div>
    <script src="../public/lib/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/localization/messages_es.js"></script>
    <script>
        const modalEditarPaciente = new bootstrap.Modal(
            document.getElementById('modalEditarPaciente'), {
            keyboard: false
        });

        // Establecer el máximo de fecha de nacimiento al día actual en el modal
        var hoy = new Date().toISOString().split('T')[0];
        document.getElementById('modal-fecha_nacimiento').setAttribute('max', hoy);

        // Limitar el input de teléfono en el modal a 10 dígitos
        $('#modal-telefono').on('input', function() {
            this.value = this.value.replace(/\D/g, '').slice(0, 10);
        });

        // Validación visual de campos vacíos en el modal
        function validarModalPaciente() {
            $("#modalEditarPaciente form").validate({
                highlight: function(element) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element) {
                    $(element).removeClass('is-invalid');
                },
                rules: {
                    'modal-nombre': "required",
                    'modal-correo': {
                        required: true,
                        email: true
                    },
                    'modal-telefono': {
                        required: true,
                        minlength: 10,
                        maxlength: 10,
                        digits: true
                    },
                    'modal-fecha_nacimiento': {
                        required: true,
                        max: hoy
                    }
                },
                messages: {
                    'modal-nombre': "Ingrese el nombre",
                    'modal-correo': {
                        required: "Ingrese el correo",
                        email: "Correo inválido"
                    },
                    'modal-telefono': {
                        required: "Ingrese el teléfono",
                        minlength: "El teléfono debe tener 10 dígitos",
                        maxlength: "El teléfono debe tener 10 dígitos",
                        digits: "Solo se permiten números"
                    },
                    'modal-fecha_nacimiento': {
                        required: "Ingrese la fecha de nacimiento",
                        max: "La fecha no puede ser mayor a hoy"
                    }
                }
            });
        }

        // Crear el formulario dinámico para el modal si no existe
        if (!$("#modalEditarPaciente form").length) {
            $('<form></form>').appendTo('#modalEditarPaciente .modal-body');
            $('#modalEditarPaciente .modal-body > div').appendTo('#modalEditarPaciente form');
        }

        validarModalPaciente();

        var tablaPacientes = document.getElementById('tabla_paciente');
        tablaPacientes.addEventListener('click', function(event){
            // Editar
            if(event.target.closest('.btn-editar-paciente')){
                var btn = event.target.closest('.btn-editar-paciente');
                var id = btn.dataset.id;
                fetch('buscarPacientePorId.php', {
                    method:'POST',
                    headers:{
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ id: id })
                }).then(function(response) {
                    return response.json();
                }).then(function(request){
                    modalEditarPaciente.show();
                    if (typeof request === 'object' && request !== null) {
                        document.getElementById('modal-id').value = request.id ?? '';
                        document.getElementById('modal-nombre').value = request.nombre ?? '';
                        document.getElementById('modal-correo').value = request.correo ?? '';
                        document.getElementById('modal-telefono').value = request.telefono ?? '';
                        document.getElementById('modal-fecha_nacimiento').value = request.fecha_nacimiento ?? '';
                    } else {
                        document.getElementById('modal-id').value = '';
                        document.getElementById('modal-nombre').value = '';
                        document.getElementById('modal-correo').value = '';
                        document.getElementById('modal-telefono').value = '';
                        document.getElementById('modal-fecha_nacimiento').value = '';
                    }
                });
            }
            // Eliminar
            if(event.target.closest('.btn-eliminar-paciente')){
                var btn = event.target.closest('.btn-eliminar-paciente');
                var id = btn.dataset.id;
                var nombrePaciente = btn.closest('tr').querySelector('td:nth-child(2)').textContent;
                Swal.fire({
                    title: `¿Seguro que deseas eliminar el paciente "${nombrePaciente}"?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Sí, eliminar',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if(result.isConfirmed){
                        fetch('eliminar.php', {
                            method:'POST',
                            headers:{
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({ id: id })
                        }).then(function(response) {
                            return response.json();
                        }).then(function(request){
                            Swal.fire({
                                icon: request.error ? 'error' : 'success',
                                title: request.error ? 'Error' : 'Eliminado',
                                text: request.error || `Paciente "${nombrePaciente}" eliminado correctamente`,
                                timer: 2000,
                                showConfirmButton: false
                            });
                            setTimeout(() => location.reload(), 1200);
                        });
                    }
                });
            }
        });

        // Actualizar paciente
        var btnActualizarPaciente = document.getElementById('btn-actualizar-paciente');
        btnActualizarPaciente.addEventListener('click', function(){
            // Validar antes de enviar
            if (!$("#modalEditarPaciente form").valid()) {
                return;
            }
            let id = document.getElementById('modal-id').value;
            let nombre = document.getElementById('modal-nombre').value;
            let correo = document.getElementById('modal-correo').value;
            let telefono = document.getElementById('modal-telefono').value;
            let fecha_nacimiento = document.getElementById('modal-fecha_nacimiento').value;

            // Mostrar Swal solo aquí
            Swal.fire({
                title: '¿Está seguro de querer modificar a este paciente?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Sí, modificar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if(result.isConfirmed){
                    fetch('actualizarPaciente.php', {
                        method:'POST',
                        headers:{
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ 
                            id: id,
                            nombre: nombre,
                            correo: correo,
                            telefono: telefono,
                            fecha_nacimiento: fecha_nacimiento
                        })
                    }).then(function(response) {
                        return response.json();
                    }).then(function(request){
                        modalEditarPaciente.hide();
                        Swal.fire({
                            icon: request.error ? 'error' : 'success',
                            title: request.error ? 'Error' : 'Actualizado',
                            text: request.error || `Paciente "${nombre}" actualizado correctamente`,
                            timer: 2000,
                            showConfirmButton: false
                        });
                        setTimeout(() => location.reload(), 1200);
                    });
                }
            });
        });
    </script>
</body>
</html>