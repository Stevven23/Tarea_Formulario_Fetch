<?php
require_once '../conexion/db.php';

// recibir datos por JSON
$request = json_decode(file_get_contents("php://input"), true);

$id = $request['id'] ?? null;

if ($id === null) {
    echo json_encode(['error' => 'ID no proporcionado']);
    exit;
}

//preparar my query
$consulta = "SELECT * FROM pacientes WHERE id = :id";
$stmt = $conn->prepare($consulta);
$stmt->bindParam(':id', $id);
$stmt->execute();
//obtener resultado
$paciente = $stmt->fetch(PDO::FETCH_ASSOC);

// imprimir datos recibidos
echo json_encode($paciente);

?>