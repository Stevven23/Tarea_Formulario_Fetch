<?php

// Conectar a base de datos con conexion/db.php
require_once '../conexion/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'] ?? '';
    $correo = $_POST['correo'] ?? '';
    $telefono = $_POST['telefono'] ?? '';
    $fecha_nacimiento = $_POST['fecha_nacimiento'] ?? '';

    try {
        $sql = "INSERT INTO pacientes (nombre, correo, telefono, fecha_nacimiento) VALUES (:nombre, :correo, :telefono, :fecha_nacimiento)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':correo', $correo);
        $stmt->bindParam(':telefono', $telefono);
        $stmt->bindParam(':fecha_nacimiento', $fecha_nacimiento);
        $stmt->execute();

        $response = [
            'success' => true,
            'message' => 'Paciente creado exitosamente'
        ];
    } catch (PDOException $e) {
        $response = [
            'success' => false,
            'error' => 'Error al guardar el paciente: ' . $e->getMessage()
        ];
    }
} else {
    $response = [
        'success' => false,
        'error' => 'Método no permitido'
    ];
}

header('Content-Type: application/json');
echo json_encode($response);
exit;
?>