<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Médico</title>
    <link href="../public/lib/bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/toastify-js/src/toastify.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #e9ecef 0%, #f8f9fa 100%);
            min-height: 100vh;
        }
        .main-header {
            background: #0d6efd;
            color: #fff;
            padding: 2rem 0 1.5rem 0;
            border-radius: 0 0 2rem 2rem;
            box-shadow: 0 4px 16px rgba(13,110,253,0.08);
        }
        .card {
            border-radius: 1rem;
            box-shadow: 0 2px 12px rgba(0,0,0,0.07);
            border: none;
            transition: transform 0.2s;
        }
        .card:hover {
            transform: translateY(-4px) scale(1.02);
            box-shadow: 0 6px 24px rgba(13,110,253,0.12);
        }
        .card-title {
            color: #0d6efd;
            font-weight: 600;
        }
        .card-text {
            color: #495057;
        }
        .btn-custom {
            background: #0d6efd;
            color: #fff;
            border-radius: 2rem;
            font-weight: 500;
            margin: 0.25rem 0;
            transition: background 0.2s;
        }
        .btn-custom:hover {
            background: #084298;
            color: #fff;
        }
        .icon-circle {
            background: #e9ecef;
            border-radius: 50%;
            padding: 0.7rem;
            font-size: 2rem;
            color: #0d6efd;
            margin-bottom: 0.5rem;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/localization/messages_es.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
</head>
<body class="bg-light">
    <header class="main-header text-center mb-5 shadow-sm">
        <h1 class="display-5 fw-bold mb-2">
            <i class="bi bi-journal-plus"></i> Crear Médico
        </h1>
        <p class="lead mb-0">Registra un nuevo médico en el sistema</p>
    </header>
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 70vh;">
        <div class="card shadow-lg w-100" style="max-width: 700px;">
            <div class="card-body">
                <form id="crearMedicoForm">
                    <div class="mb-3">
                        <label for="nombre" class="form-label">Nombre del médico</label>
                        <input type="text" class="form-control" id="nombre" name="nombre" required placeholder="Ej. Juan Pérez">
                    </div>
                    <div class="mb-3">
                        <label for="especialidad" class="form-label">Especialidad</label>
                        <input type="text" class="form-control" id="especialidad" name="especialidad" required maxlength="30" placeholder="Ej. Cardiología">
                    </div>
                    <div class="mb-3">
                        <label for="tarifa_por_hora" class="form-label">Tarifa Por Hora</label>
                        <input type="number" class="form-control" id="tarifa_por_hora" name="tarifa_por_hora" required placeholder="Ej. 100">
                    </div>
                    <button type="submit" class="btn btn-custom w-100">
                        <i class="bi bi-check-circle"></i> Crear Médico
                    </button>
                    <a
                        href="../index.html"
                        class="btn btn-outline-primary w-100 mt-2 shadow-sm d-flex align-items-center justify-content-center"
                        style="font-weight: 500;"
                    >
                        <i class="bi bi-arrow-left-circle me-2"></i> Regresar
                    </a>
                </form>
                <!-- Tabla de médicos ingresados -->
                <hr class="my-4">
                <h4 class="text-center mb-3 text-secondary"><i class="bi bi-journal-text"></i> Médicos Ingresados</h4>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped align-middle text-center">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Especialidad</th>
                                <th>Tarifa Por Hora</th>
                            </tr>
                        </thead>
                        <tbody id="tabla-medicos-body">
                            <?php
                            require_once '../conexion/db.php';
                            $sql = "SELECT * FROM medicos";
                            $result = $conn->query($sql);
                            $medicos = $result->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($medicos as $medico): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($medico['id']); ?></td>
                                    <td><?php echo htmlspecialchars($medico['nombre']); ?></td>
                                    <td><?php echo htmlspecialchars($medico['especialidad']); ?></td>
                                    <td><?php echo htmlspecialchars($medico['tarifa_por_hora']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <footer class="text-center mt-5 mb-3 text-muted small">
        &copy; <?php echo date('Y'); ?> Gestión de Citas Médicas
    </footer>
    <script src="../public/lib/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function() {
            // Validación visual de campos vacíos
            $("#crearMedicoForm").validate({
                highlight: function(element) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element) {
                    $(element).removeClass('is-invalid');
                },
                rules: {
                    nombre: "required",
                    especialidad: {
                        required: true,
                        maxlength: 30
                    },
                    tarifa_por_hora: {
                        required: true,
                        number: true,
                        min: 1
                    }
                },
                messages: {
                    nombre: "Ingrese el nombre del médico",
                    especialidad: {
                        required: "Ingrese la especialidad",
                        maxlength: "Máximo 30 caracteres"
                    },
                    tarifa_por_hora: {
                        required: "Ingrese la tarifa por hora",
                        number: "Solo números",
                        min: "Debe ser mayor a 0"
                    }
                },
                submitHandler: function(form) {
                    const formData = new FormData(form);
                    const nombreMedico = $('#nombre').val();
                    fetch('guardar_medico.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Toastify({
                                text: `Médico "${nombreMedico}" ingresado exitosamente`,
                                duration: 3000,
                                gravity: "top",
                                position: "right",
                                style: { background: "linear-gradient(to right, #00b09b, #96c93d)" }
                            }).showToast();
                            form.reset();
                            $(".form-control").removeClass("is-invalid");
                            setTimeout(() => {
                                window.location.reload();
                            }, 2000);
                        } else {
                            Toastify({
                                text: data.error || "Error al ingresar el médico",
                                duration: 3000,
                                gravity: "top",
                                position: "right",
                                style: { background: "linear-gradient(to right, #ff5f6d, #ffc371)" }
                            }).showToast();
                        }
                    })
                    .catch(() => {
                        Toastify({
                            text: "Error al conectar con el servidor",
                            duration: 3000,
                            gravity: "top",
                            position: "right",
                            style: { background: "linear-gradient(to right, #ff5f6d, #ffc371)" }
                        }).showToast();
                    });
                }
            });
        });
    </script>
</body>
</html>
