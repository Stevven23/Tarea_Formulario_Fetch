<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Paciente</title>
    <link href="../public/lib/bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/toastify-js/src/toastify.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #e9ecef 0%, #f8f9fa 100%);
            min-height: 100vh;
        }
        .main-header {
            background: #0d6efd;
            color: #fff;
            padding: 2rem 0 1.5rem 0;
            border-radius: 0 0 2rem 2rem;
            box-shadow: 0 4px 16px rgba(13,110,253,0.08);
        }
        .card {
            border-radius: 1rem;
            box-shadow: 0 2px 12px rgba(0,0,0,0.07);
            border: none;
            transition: transform 0.2s;
        }
        .card:hover {
            transform: translateY(-4px) scale(1.02);
            box-shadow: 0 6px 24px rgba(13,110,253,0.12);
        }
        .card-title {
            color: #0d6efd;
            font-weight: 600;
        }
        .card-text {
            color: #495057;
        }
        .btn-custom {
            background: #0d6efd;
            color: #fff;
            border-radius: 2rem;
            font-weight: 500;
            margin: 0.25rem 0;
            transition: background 0.2s;
        }
        .btn-custom:hover {
            background: #084298;
            color: #fff;
        }
        .icon-circle {
            background: #e9ecef;
            border-radius: 50%;
            padding: 0.7rem;
            font-size: 2rem;
            color: #0d6efd;
            margin-bottom: 0.5rem;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/localization/messages_es.js"></script>
    <script>
        $(document).ready(function() {
            // Establecer el máximo de fecha de nacimiento al día actual
            var hoy = new Date().toISOString().split('T')[0];
            $('#fecha_nacimiento').attr('max', hoy);

            // Limitar el input de teléfono a 10 dígitos
            $('#telefono').on('input', function() {
                this.value = this.value.replace(/\D/g, '').slice(0, 10);
            });

            // Validación visual de campos vacíos
            $("#crearPacienteForm").validate({
                highlight: function(element) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element) {
                    $(element).removeClass('is-invalid');
                },
                rules: {
                    nombre: "required",
                    correo: {
                        required: true,
                        email: true
                    },
                    telefono: {
                        required: true,
                        minlength: 10,
                        maxlength: 10,
                        digits: true
                    },
                    fecha_nacimiento: {
                        required: true,
                        max: hoy
                    }
                },
                messages: {
                    telefono: {
                        minlength: "El teléfono debe tener 10 dígitos",
                        maxlength: "El teléfono debe tener 10 dígitos",
                        digits: "Solo se permiten números"
                    },
                    fecha_nacimiento: {
                        max: "La fecha no puede ser mayor a hoy"
                    }
                },
                submitHandler: function(form) {
                    const formData = new FormData(form);
                    fetch('guardar.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Toastify({
                                text: "Paciente creado exitosamente",
                                duration: 3000,
                                gravity: "top",
                                position: "right",
                                style: { background: "linear-gradient(to right, #00b09b, #96c93d)" }
                            }).showToast();
                            form.reset();
                            $(".form-control").removeClass("is-invalid");
                            setTimeout(() => {
                                window.location.reload();
                            }, 2000);
                        } else {
                            Toastify({
                                text: data.error || "Error al crear el paciente",
                                duration: 3000,
                                gravity: "top",
                                position: "right",
                                style: { background: "linear-gradient(to right, #ff5f6d, #ffc371)" }
                            }).showToast();
                        }
                    })
                    .catch(() => {
                        Toastify({
                            text: "Error al conectar con el servidor",
                            duration: 3000,
                            gravity: "top",
                            position: "right",
                            style: { background: "linear-gradient(to right, #ff5f6d, #ffc371)" }
                        }).showToast();
                    });
                }
            });
        });
    </script>
</head>
<body class="bg-light">
    <header class="main-header text-center mb-5 shadow-sm">
        <h1 class="display-5 fw-bold mb-2">
            <i class="bi bi-person-plus"></i> Crear Paciente
        </h1>
        <p class="lead mb-0">Registra un nuevo paciente en el sistema</p>
    </header>
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 70vh;">
        <div class="card shadow-lg w-100" style="max-width: 700px;">
            <div class="card-body">
                <form id="crearPacienteForm">
                    <div class="mb-3">
                        <label for="nombre" class="form-label">Nombre</label>
                        <input type="text" class="form-control" id="nombre" name="nombre" required placeholder="Ej. Juan Pérez">
                    </div>
                    <div class="mb-3">
                        <label for="correo" class="form-label">Correo</label>
                        <input type="email" class="form-control" id="correo" name="correo" required placeholder="Ej. juan@email.com">
                    </div>
                    <div class="mb-3">
                        <label for="telefono" class="form-label">Teléfono</label>
                        <input type="tel" class="form-control" id="telefono" name="telefono" required 
                            placeholder="Ej. 5551234567" maxlength="10" pattern="\d{10}">
                        <div class="form-text">Debe contener exactamente 10 números.</div>
                    </div>
                    <div class="mb-3">
                        <label for="fecha_nacimiento" class="form-label">Fecha de Nacimiento</label>
                        <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento" required>
                    </div>
                    <button type="submit" class="btn btn-custom w-100">
                        <i class="bi bi-check-circle"></i> Crear Paciente
                    </button>
                    <a
                        href="../index.html"
                        class="btn btn-outline-primary w-100 mt-2 shadow-sm d-flex align-items-center justify-content-center"
                        style="font-weight: 500;"
                    >
                        <i class="bi bi-arrow-left-circle me-2"></i> Regresar
                    </a>
                </form>
                <!-- Tabla de pacientes ingresados -->
                <hr class="my-4">
                <h4 class="text-center mb-3 text-secondary"><i class="bi bi-people"></i> Pacientes Ingresados</h4>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped align-middle text-center">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Correo</th>
                                <th>Teléfono</th>
                                <th>Fecha Nacimiento</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            require_once '../conexion/db.php';
                            $sql = "SELECT * FROM pacientes";
                            $result = $conn->query($sql);
                            $pacientes = $result->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($pacientes as $paciente): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($paciente['id']); ?></td>
                                    <td><?php echo htmlspecialchars($paciente['nombre']); ?></td>
                                    <td><?php echo htmlspecialchars($paciente['correo']); ?></td>
                                    <td><?php echo htmlspecialchars($paciente['telefono']); ?></td>
                                    <td><?php echo htmlspecialchars($paciente['fecha_nacimiento']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <footer class="text-center mt-5 mb-3 text-muted small">
        &copy; <?php echo date('Y'); ?> Gestión de Citas Médicas
    </footer>
    <script src="../public/lib/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
</body>
</html>