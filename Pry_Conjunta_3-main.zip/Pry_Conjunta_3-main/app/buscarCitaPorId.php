<?php
require_once '../conexion/db.php';
$request = json_decode(file_get_contents("php://input"), true);

$id = $request['id'] ?? null;
if (!$id) {
    echo json_encode(['error' => 'ID de cita no proporcionado']);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM citas WHERE id = :id");
$stmt->bindParam(':id', $id);
$stmt->execute();
$cita = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode($cita);
?>